# SC Horses Veterinary

Responsive English / German veterinary workspace, black and silver design.

## Run

No build or dependencies required. Run `python3 -m http.server 8080` inside this directory and open http://localhost:8080. Use a web server, rather than double-clicking index.html.

## GitHub Pages

1. Create a GitHub repository (for example `sc-horses`).
2. Extract this archive. Upload the contents of this directory to the repository root, including `.github/workflows/pages.yml`. Do not upload the ZIP itself as the app.
3. Ensure the default branch is `main`.
4. In Settings → Pages → Build and deployment, select **GitHub Actions**.
5. Run the `Deploy to GitHub Pages` workflow, or push a commit. Its deployment output provides the URL.

Command line alternative:

```sh
git init
git add .
git commit -m "Initial SC Horses Veterinary local workspace"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/sc-horses.git
git push -u origin main
```

## Included

- Responsive welcome and home screens, EN/DE language selection.
- Patient, Client, X-ray, Ultrasound, Schedule, Team, Rehabilitation, Pharmacy.
- Add, edit, delete, search records; appointments sorted by date and time.
- Local browser persistence, JSON backup export and validated restore.
- Offline asset cache after the first successful visit; installable web manifest.
- No external scripts, fonts, analytics or API dependencies.

## Scope and data

This release is a **single-browser local edition**. Open workspace is not authentication. There are no user accounts, access roles, server backups or multi-device synchronization. Anyone using the browser profile can access its records. Clearing browser data removes records; export backups regularly. JSON backups contain plaintext records and must be handled accordingly.

X-ray and Ultrasound store report text and image references, not uploaded DICOM/images. Pharmacy records stock quantities; it does not maintain a dispensing transaction ledger. This is not a diagnostic tool. Before using real confidential clinical data, implement appropriate authentication, authorization, secure server storage and backup procedures for the intended deployment.

## Validation

`node --check app.js`, `node --check sw.js`, and `node tests/smoke.cjs`. Browser visual and device installation tests remain to be performed. GitHub deployment requires the user's repository and was not performed as part of this ZIP delivery.

Brand supplied by the user; horse background generated for this project. No license to the user's brand is granted to third parties.

## Platform support

Responsive web application for modern Android and iOS browsers. Add to Home Screen on iPhone via Safari, or install through the Android browser menu when offered. HTTPS hosting is required for offline caching. Installation availability varies by browser; this is not an APK or App Store package. Local data are isolated per browser/installation; export a backup before changing installation or device.

Welcome tagline: Show Jumping Veterinary Care / Tiermedizin für Springpferde.
