const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const nodes=new Map();const node=()=>({innerHTML:'',textContent:'',addEventListener(){},showModal(){},close(){}});const storage=new Map();const ctx={console,localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},document:{documentElement:{},querySelector:s=>{if(!nodes.has(s))nodes.set(s,node());return nodes.get(s)},querySelectorAll:()=>[]},navigator:{},location:{protocol:'http:'},alert(){},confirm:()=>true,crypto:require('node:crypto').webcrypto,setTimeout,Blob,URL};vm.createContext(ctx);vm.runInContext(fs.readFileSync('app.js','utf8'),ctx);vm.runInContext(`
if(Object.keys(modules).length!==8)throw Error('modules');
if(!valid({version:1,records:blank()}))throw Error('valid backup');
if(valid({version:1,records:{}}))throw Error('invalid backup accepted');
if(esc('<script>')!=='&lt;script&gt;')throw Error('escaping');
const next=blank();next.patient.push({id:'test',name:'Midnight'});if(!persist(next))throw Error('persist');
if(JSON.parse(localStorage.getItem(KEY)).records.patient[0].name!=='Midnight')throw Error('storage');
for(const p of ['home','profile','settings',...Object.keys(modules)]){page=p;render();}
lang='de';for(const p of ['welcome','home',...Object.keys(modules)]){page=p;render();}
`,ctx);assert.ok(nodes.get('#app').innerHTML.includes('Apotheke'));console.log('PASS: eight modules, both languages, render routes, storage, backup validation and HTML escaping');
