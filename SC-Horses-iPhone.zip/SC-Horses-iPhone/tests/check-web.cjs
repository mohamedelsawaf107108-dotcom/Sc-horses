const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.join(__dirname,'../web');const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
let scripts=0;for(const m of html.matchAll(/<script>([\s\S]*?)<\/script>/g)){new vm.Script(m[1]);scripts++;}
for(const name of ['pwa.js','sw.js'])new vm.Script(fs.readFileSync(path.join(root,name),'utf8'));
const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.webmanifest'),'utf8'));assert.equal(manifest.display,'standalone');assert.equal(manifest.start_url,'./');assert.equal(manifest.scope,'./');
for(const icon of manifest.icons)assert(fs.existsSync(path.join(root,icon.src)));
assert(html.includes('apple-touch-icon'));assert(html.includes('viewport-fit=cover'));assert(html.includes('pwa.js'));assert.equal(scripts,4);
for(const m of html.matchAll(/(?:src|href)="(\.\/[^"#?]+)"/g))assert(fs.existsSync(path.join(root,m[1])),m[1]);
const worker=fs.readFileSync(path.join(root,'sw.js'),'utf8');assert(worker.includes("url.pathname.includes('/api/')"));assert(worker.includes("request.method!=='GET'"));assert(!worker.includes('cache.put'));
console.log('PASS: all bundled scripts parse; standalone manifest, local assets, safe-area metadata and API cache exclusions checked');
