# SC Horses iPhone web app

An installable web adaptation of the SC Horses Android workspace. Same English/German modules, 803 imported medicine rows, 187 treatment/service rows and named 17-entry team directory (including two explicit groom placeholders). No real patient records are seeded. Includes a Pages workflow that extracts SC-Horses-iPhone.zip and publishes only `web/`.

See `START-HERE-AR.md` for mobile upload/install steps. Enable GitHub Pages → GitHub Actions, put the workflow outside the archive at `.github/workflows/deploy-iphone.yml`, and run **Publish SC Horses iPhone**. Deployment replaces the GitHub Pages site at that repository's URL; it does not alter the Android APK.

## What changed for iPhone

- Relative-path manifest, standalone display and company touch icons.
- Notch/home-indicator safe areas, touch targets, 16px inputs, usable dialogs.
- Complete company wordmark fits the header instead of clipping it.
- Deduplicated local image assets, with no external image dependencies.
- Service worker caches the exact app shell. Navigation has a network timeout/offline fallback. No API responses or writes enter the cache. Cache cleanup is limited to this app's scope.
- Waiting updates require a user action; an open edit dialog must be closed first.
- Settings explain Safari installation, offline readiness, local storage and shared-server setup.
- Backup downloads to Files; restore uses the normal file picker. Existing backup schema/key remains compatible.
- Printable invoice opens inside the app window to avoid popup restrictions. System print/share options still depend on iOS.

## Shared records

`server/` contains the same optional Python API. It must be deployed separately behind HTTPS with persistent storage. Configure exact origins in `SC_ALLOWED_ORIGINS`: include the GitHub Pages origin and Android appassets origin for mixed-device access. Local device records are separate from server records. Initial migration uses an exported backup; no records are silently merged or uploaded.

## Build/check

```bash
python3 build_offline.py
node tests/check-web.cjs
```

After any web change run `build_offline.py` to hash current assets and regenerate `sw.js`. Keep the same origin and manifest scope for future updates. Export backups before changing domains, browser data or installation mode. Browser-managed storage is not a backup service.

This delivery is a PWA source package, not an IPA, App Store release or hosted database. Native iOS packaging would require a separate Apple build/sign/distribution setup. Clinical images remain reference notes; no DICOM viewer has been added. Direct bank APIs, automatic messaging and background synchronization are not provided by this adaptation. Device acceptance testing is required before real practice use.
