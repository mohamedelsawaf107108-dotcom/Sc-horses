"""Regenerate bundled operation extensions after editing their source files."""
from pathlib import Path
import re
root=Path(__file__).parent;p=root/'app/src/main/assets/index.html';s=p.read_text()
s=re.sub(r'// OPERATIONS_SCHEMA_BEGIN.*?// OPERATIONS_SCHEMA_END\n','',s,flags=re.S)
s=s.replace('const blank=','// OPERATIONS_SCHEMA_BEGIN\n'+(root/'operations-schema.js').read_text()+'\n// OPERATIONS_SCHEMA_END\nconst blank=',1)
s=s.replace("(k==='services'&&v.records[k]===undefined)","(!['patient','client','xray','ultrasound','schedule','team','rehabilitation','pharmacy'].includes(k)&&v.records[k]===undefined)")
s=s.replace('file.size>5000000','file.size>20000000')
s=re.sub(r'<!-- OPERATIONS_BEGIN -->.*?<!-- OPERATIONS_END -->','',s,flags=re.S)
styles='''<style>.shell{padding-bottom:110px}.record{overflow-wrap:anywhere}.record h3{line-height:1.4}.record p{line-height:1.6}.invoice-line{border:1px solid var(--line);border-radius:16px;padding:16px;margin:16px 0}.invoice-line h3{margin-top:0}select{width:100%;color:inherit;background:#202328;border:1px solid var(--line);border-radius:10px;padding:12px}#fields label{display:block;margin:14px 0 6px;font-size:13px;color:#bbc2cc}.account-choice{display:flex!important;align-items:center;gap:10px;padding:9px;border:1px solid #353942;border-radius:10px}.account-choice input{width:auto!important}.actions{display:flex;gap:8px;flex-wrap:wrap}.toolbar{flex-wrap:wrap}.toolbar h1{font-size:23px}#cloudLogin input{display:block;width:100%;margin-bottom:12px;padding:12px;background:#17191d;border:1px solid #434852;color:white;border-radius:10px}.portal-header{border-bottom:1px solid var(--line);padding:18px 0;margin-bottom:20px}.portal-header h1{font-size:30px}.note{line-height:1.65}</style>'''
s=s.replace('</head>',styles+'</head>',1) if '.portal-header{' not in s else s
block='<!-- OPERATIONS_BEGIN --><script>\n'+(root/'operations.js').read_text()+'\n</script><!-- OPERATIONS_END -->'
s=s.replace('</body>',block+'</body>') if '</body>' in s else s+block
p.write_text(s)
