# SC Horses Android

Offline Android WebView application, Android 8.0+.

Includes bundled English/German veterinary workspace and imagery. No internet permission; all records are local to this installation. Export and import backups through Android's document picker. Website records are not automatically copied into this app: export a backup from the website and restore it in the app.

## Build in Android Studio
Open this directory as a Gradle project. JDK 17, Gradle 8.9, Android SDK 35 and Build Tools 34.0.0. Run `gradle assembleDebug`. The output is `app/build/outputs/apk/debug/app-debug.apk`.

## Build through GitHub with ZIP upload
Upload SC-Horses-Android.zip to repository root. Create `.github/workflows/build-apk.yml` using the supplied matching workflow. After committing, open Actions > Build Android APK. Download SC-Horses-APK from Artifacts in the successful run, extract the artifact ZIP, then install app-debug.apk on Android.

This is a DEBUG signed test APK, not a production Google Play release. Each fresh GitHub runner may generate a different debug signing key; an APK built by a later run may not update an existing install. Before uninstalling or changing builds, export a backup. Production updates require a retained private release signing key; no release key is supplied or embedded here.

No accounts, cloud sync, clinical image uploads or server storage. APK build and physical-device testing have not been completed in the authoring environment because the Android SDK and Gradle are unavailable. Source syntax and packaged HTML were checked only. iOS installation is not provided by this Android project.

## Version 1.1
Company launcher icon replaces Android default. Imports all 803 nonempty MDET.xlsx rows once, retains all 67 source columns per row as original JSON, including 311 negative inventory balances. Two nameless rows labeled with code and ID. No currency inferred. Source dosage text is imported verbatim, not validated clinical prescribing guidance. Existing local records retained; JSON backups include catalog fields. Pharmacy renders 40 results at a time with Show more; search covers all records. VersionCode 2. APK build and device testing still required.
