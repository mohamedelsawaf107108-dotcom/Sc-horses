# SC Horses Veterinary 2.0 — Android + optional shared API

Installable Android app source (Android 8+) with an English/German interface, company icon, bundled welcome imagery, and local storage. Package/application ID remains `com.schorses.veterinary`. This delivery contains source, not a prebuilt APK. iOS is not built by this project.

## Upload one ZIP to GitHub

1. Upload **SC-Horses-Android.zip** to your repository's root, replacing the previous archive.
2. In the repository itself create or replace **.github/workflows/build-apk.yml** with the file supplied alongside the ZIP. A workflow inside an uploaded ZIP cannot start itself; this one external YAML file is necessary once.
3. Open **Actions → Build Android APK → Run workflow**. The workflow extracts the archive, runs checks and builds the APK.
4. When it succeeds, download **SC-Horses-APK** under Artifacts. Extract that download and install its APK.

The workflow supports either the uploaded ZIP or extracted project source. It does not need `setup-android` or automatic SDK-license acceptance; it checks the runner's existing SDK 35. A failed run must be diagnosed from its first actual error.

## What is included

- Patient/client files, visits, appointment schedule, X-ray/ultrasound study metadata and report notes.
- Named directory: Dr. Marc, Dr. Zlati, Dr. Camille; technicians Fabienne, Marta, Victoria, Ingrid, Sabina, Kadri; office Annemarie, Kati, Danique, Vanessa; rehab Gabi and two explicitly unnamed groom placeholders; farrier Joël. Directory entries are not login accounts.
- All 803 medicine rows and 187 service rows from the supplied spreadsheets. Original columns remain in backups. No fabricated product prices, currencies, dose recommendations or tax mappings.
- Searchable compact catalog cards with details, pagination and stock alerts for imported historic balances.
- Location/batch inventory ledger: receipts/opening balances, transfers, patient use, waste, batch and expiry fields, current balances by location. NL/CH warehouses and three vehicles are prelisted. Add competition locations as needed. Historical imported balances are not automatically allocated to locations: enter verified opening balances. Invoice creation does not silently dispense stock.
- Visits linked to horses and clients, with an action to start a related invoice draft. Add service/medicine lines, edit quantity/price, discounts, explicit tax rate and reverse-charge/exemption reason. Owner and invoice recipient can differ.
- Billing-entity settings for NL/CH, EUR/CHF, address, tax registration, bank/IBAN and numbering prefix. Actual company/bank data must be entered. Office reviews drafts; issued documents retain snapshots and cannot be edited/deleted.
- Manual payments, partial payments, unpaid-balance credit notes with a reason, remaining balances, overdue lists and configurable 14-day / further 10-day reminder thresholds. Fees are settings for manual review, never silently added to issued invoices. To correct an unpaid invoice: issue a credit note, then a new corrected invoice. Paid-invoice refunds require a separate accounting process.
- Invoice text sharing through Android's share sheet (select Mail/WhatsApp), and PDF output through Android's print dialog. Sending is performed by the user. Credit notes can also be shared as text.
- Bank CSV reconciliation: standardize your export to `server/bank-statement-template.csv`, preview all rows and confirm. Rejects mismatched invoices/currencies, overpayments and duplicates. This is **not** a live Rabobank/Clientis connection.
- Rehab plans with arrivals/departures, farriery records and explicitly shared reports. X-rays and medical images are metadata/reference notes; DICOM/image upload/storage/viewing is not implemented.
- Backup/restore, audit trail, and optional shared-server accounts. Local mode is single-user and unrestricted. Roles protect records only in server mode.

## Shared accounts and permissions

See **server/README.md**. Host that service behind HTTPS with a persistent SQLite database, create the first admin and import a local backup. Then connect from **Cloud & accounts** in the app. Data remain separate: signing into the server does not upload local files automatically. Sessions stay in memory and sign out when the app process ends; refresh manually before editing stale records.

The server enforces permissions independently of hidden UI buttons:

| Role | Scope |
| --- | --- |
| Admin / Office | All practice records; office billing; only admin creates accounts |
| Vet | Assigned horses, clinical entries, catalog and stock movements; creates invoice drafts and sees payment status, not purchase prices or invoice amounts |
| Technician | Assigned clinical records; scheduling and rehabilitation edits |
| Rehab | Assigned horses and rehab records; rehab edits |
| Client | Own horses, approved reports/plans, appointments and own invoices; read only |
| Manager | Assigned horses, approved reports/plans and appointments; read only |
| Farrier | Assigned horses, explicitly released X-ray/report notes, appointments and own hoof-care entries |

Office assigns access in each patient's editor using account selectors. Link a client account in its client record, then link that client to its horses. Choose `internal` unless a report/plan is intended to be shared. Existing legacy records need patient links added before scoped users can see them. Source metadata and purchase fields are removed from non-office pharmacy responses. Server revisions reject stale saves; refresh and retry rather than overwriting another user's work.

## Stable Android updates — important

Matching package IDs alone do not solve the Android “package conflicts” message. Future APKs also need the **same signing certificate** and a higher versionCode. This project preserves the ID and increases build versions. It cannot reconstruct the certificate used by an old installation.

Without signing secrets, Actions builds a debug APK and warns that a new runner may use a different debug certificate. For retained signing:

1. On a trusted computer with JDK17 run `bash tools/create-signing-key.sh` once. Save the private output directory outside the repository in a secure backup.
2. Set GitHub **Settings → Secrets and variables → Actions** secrets:
   - `ANDROID_KEYSTORE_BASE64`: contents of the generated text file.
   - `ANDROID_KEYSTORE_PASSWORD`: the keystore password.
   - `ANDROID_KEY_ALIAS`: `sc-horses`.
   - `ANDROID_KEY_PASSWORD`: the key password (usually the same).
3. Every future run uses that same key and builds release APKs. Never change the key, and keep versionCode higher if moving repositories/workflows.

If the installed app used a different lost debug key, export its JSON backup before uninstalling it; install the first consistently signed version and restore the backup. Never uninstall before checking the backup.

## Checks and limitations

Run `node tests/test_frontend.cjs` and `python3 -m unittest discover -s tests -v`. Checks cover catalog counts, old/new backups, bilingual render routes, invoice rounding, stock transfers, credits, record scopes, immutable invoices, concurrent-save rejection, audit creation and stock/payment limits.

These are source/API checks, not a substitute for Android compilation and device acceptance testing. APK compilation and a physical-device installation were not run in the authoring environment (Android SDK/Gradle unavailable). The CI workflow performs the build after upload.

The shared API is a small deployable foundation, not a managed production service. Before real practice use, deploy and back up the server, test each actual staff account, confirm accounting rules and tax configuration with the practice, and perform device and privacy acceptance checks. There is no active hosted server, live bank integration, automatic email/WhatsApp dispatch, push notifications, DICOM viewer, iOS build, or App Store/Play publication in this ZIP.

To edit operation screens: update `operations-schema.js` / `operations.js`, then run `python3 integrate.py` to rebuild the single bundled HTML. Do not store credentials, keystores or patient backups in a public repository.
