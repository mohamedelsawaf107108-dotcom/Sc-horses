#!/usr/bin/env bash
set -euo pipefail
umask 077
out="${1:-sc-horses-signing}"
mkdir -p "$out"
if [ -e "$out/sc-release.jks" ]; then
  echo 'Existing key found; refusing to replace it.' >&2
  exit 1
fi
# keytool prompts for a password; secrets are never hardcoded in the project.
keytool -genkeypair -v -keystore "$out/sc-release.jks" -storetype JKS -alias sc-horses -keyalg RSA -keysize 3072 -validity 10000 -dname 'CN=SC Horses Veterinary'
base64 < "$out/sc-release.jks" | tr -d '\n' > "$out/ANDROID_KEYSTORE_BASE64.txt"
printf '\nSave this directory privately. Upload only the four values as GitHub Actions secrets. Never commit the key.\n'
