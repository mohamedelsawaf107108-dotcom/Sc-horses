package com.schorses.veterinary;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> upload;
    private String pendingBackup;
    private static final String ORIGIN = "https://appassets.androidplatform.net";
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xff101113);
        setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new BackupBridge(), "SCAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if ((ORIGIN + "/index.html").equals(request.getUrl().toString())) {
                    try { return new WebResourceResponse("text/html", "UTF-8", getAssets().open("index.html")); }
                    catch (IOException e) { return blocked(); }
                }
                return blocked();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !(ORIGIN + "/index.html").equals(request.getUrl().toString());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView v, String url, String message, JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton(android.R.string.ok,(d,w)->result.confirm()).setOnCancelListener(d->result.cancel()).show();return true;
            }
            @Override public boolean onJsConfirm(WebView v, String url, String message, JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton(android.R.string.ok,(d,w)->result.confirm()).setNegativeButton(android.R.string.cancel,(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if(upload != null) upload.onReceiveValue(null);
                upload = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE);
                try { startActivityForResult(intent, 10); }
                catch(Exception e) { upload.onReceiveValue(null); upload=null; }
                return true;
            }
        });
        web.loadUrl(ORIGIN + "/index.html");
    }
    private WebResourceResponse blocked() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", null, new ByteArrayInputStream(new byte[0]));
    }
    public class BackupBridge {
        @JavascriptInterface public void saveBackup(String json) {
            if(json == null || json.length() > 5_000_000) return;
            runOnUiThread(()->{
                if(pendingBackup != null) return;
                pendingBackup=json;
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,"SC-Horses-backup.json");
                try { startActivityForResult(intent,11); }
                catch(Exception e) { pendingBackup=null; Toast.makeText(MainActivity.this,"Unable to open file picker",Toast.LENGTH_LONG).show(); }
            });
        }
    }
    @Override protected void onActivityResult(int request, int result, Intent intent) {
        super.onActivityResult(request,result,intent);
        if(request==10 && upload != null) {
            upload.onReceiveValue(result==RESULT_OK && intent != null && intent.getData()!=null ? new Uri[]{intent.getData()} : null);upload=null;
        }
        if(request==11) {
            String text=pendingBackup;pendingBackup=null;
            if(result==RESULT_OK && intent!=null && intent.getData()!=null && text!=null) {
                try(OutputStream out=getContentResolver().openOutputStream(intent.getData(),"wt")) {
                    if(out==null) throw new IOException();
                    out.write(text.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"Backup saved",Toast.LENGTH_SHORT).show();
                } catch(IOException e) { Toast.makeText(this,"Backup could not be saved",Toast.LENGTH_LONG).show(); }
            }
        }
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("(()=>{const d=document.querySelector('#editor');if(d&&d.open){d.close();return;}if(typeof page!=='undefined'&&page!=='welcome'){page=page==='home'?'welcome':'home';query='';render();}})()",null);
    }
    @Override protected void onDestroy() {
        if(upload!=null)upload.onReceiveValue(null);
        web.removeJavascriptInterface("SCAndroid");web.destroy();super.onDestroy();
    }
}
