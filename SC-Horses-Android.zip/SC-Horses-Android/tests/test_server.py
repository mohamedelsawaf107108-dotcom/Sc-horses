import importlib.util,json,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('api',Path(__file__).parents[1]/'server/server.py');api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
class ApiTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();api.DB=str(Path(self.tmp.name)/'test.sqlite');api.init();self.c=api.connect();self.admin=('a','Office','admin');self.vet=('v','Dr. Marc','vet');self.client=('c','Owner','client')
  seed={'patient':[{'id':'p','name':'Horse','clientId':'owner','assignedTo':'v'},{'id':'hidden','name':'Hidden','assignedTo':'other'}],'client':[{'id':'owner','name':'Owner','accountId':'c'}],'locations':[{'id':'nl','name':'Warehouse'},{'id':'car','name':'Car'}],'pharmacy':[{'id':'med','name':'Medicine','purchase':'12','sourceData':'secret'}],'billing':[{'id':'entity','name':'Practice','prefix':'SC','currency':'EUR','address':'Address','vatNumber':'VAT'}]}
  for m,rows in seed.items():
   for r in rows:self.c.execute('INSERT INTO records VALUES(?,?,?)',(m,r['id'],json.dumps(r)))
  self.c.commit()
 def tearDown(self):self.c.close();self.tmp.cleanup()
 def apply(self,changes,user=None):
  u=user or self.admin;state=api.state_result(self.c,u);state['records'].update(changes);result=api.commit_state(self.c,u,state);self.c.commit();return result
 def draft(self,id='inv'):
  return {'id':id,'name':'Draft','patientId':'p','clientId':'owner','entityId':'entity','currency':'EUR','items':json.dumps([{'name':'Visit','quantity':'2','price':'12.50'}]),'discount':'10','tax':'20','taxMode':'standard','totalCents':'2700','status':'draft','date':'2026-10-27','due':'2026-11-10'}
 def issue(self):
  self.apply({'invoices':[self.draft()]});r=api.load(self.c)['invoices'][0];r.update(status='issued',number='SC-000001',entitySnapshot='{}',clientSnapshot='{}');self.apply({'invoices':[r]});return api.load(self.c)['invoices'][0]
 def test_scope_and_redaction(self):
  v=api.visible(api.load(self.c),self.vet);self.assertEqual([r['id'] for r in v['patient']],['p']);self.assertNotIn('purchase',v['pharmacy'][0]);self.assertNotIn('sourceData',v['pharmacy'][0]);c=api.visible(api.load(self.c),self.client);self.assertEqual([r['id'] for r in c['patient']],['p']);self.assertNotIn('assignedTo',c['patient'][0])
 def test_client_cannot_write(self):
  with self.assertRaisesRegex(ValueError,'Permission'):self.apply({'patient':[{'id':'p','name':'Changed'}]},self.client)
 def test_vet_cannot_expand_scope(self):
  r=api.visible(api.load(self.c),self.vet)['patient'][0];r['assignedTo']='v,other'
  with self.assertRaisesRegex(ValueError,'Only office'):self.apply({'patient':[r]},self.vet)
 def test_global_revision_prevents_overwrite(self):
  old=api.state_result(self.c,self.admin);self.apply({'reports':[{'id':'r','name':'Report'}]})
  with self.assertRaisesRegex(ValueError,'Refresh'):api.commit_state(self.c,self.admin,old)
 def test_invoice_calculation_and_lock(self):
  inv=self.issue();self.assertEqual(inv['number'],'SC-000001');self.assertIn('Practice',inv['entitySnapshot']);inv['totalCents']='0'
  with self.assertRaisesRegex(ValueError,'locked'):self.apply({'invoices':[inv]})
 def test_bad_invoice_total_rejected(self):
  inv=self.draft();inv['totalCents']='1'
  with self.assertRaisesRegex(ValueError,'mismatch'):self.apply({'invoices':[inv]})
 def test_stock_multiple_entries_cannot_overdraw(self):
  base={'productId':'med','batch':'B','quantity':'5','from':'','to':'nl','kind':'receipt'};self.apply({'movements':[dict(base,id='m1')]});existing=api.load(self.c)['movements'];a=dict(base,id='m2',kind='transfer',quantity='4',**{'from':'nl','to':'car'});b=dict(a,id='m3')
  with self.assertRaisesRegex(ValueError,'Insufficient'):self.apply({'movements':existing+[a,b]})
  self.assertEqual(len(api.load(self.c)['movements']),1)
 def test_payments_and_credit_balance(self):
  inv=self.issue();self.apply({'payments':[{'id':'pay','invoiceId':inv['id'],'amountCents':'700','currency':'EUR'}]});self.apply({'credits':[{'id':'cn','invoiceId':inv['id'],'amountCents':'1000','currency':'EUR','reason':'Correction'}]});view=api.state_result(self.c,self.client);self.assertEqual(view['records']['invoices'][0]['outstandingCents'],'1000')
  with self.assertRaisesRegex(ValueError,'Invalid payment'):self.apply({'payments':api.load(self.c)['payments']+[{'id':'over','invoiceId':inv['id'],'amountCents':'1001','currency':'EUR'}]})
 def test_vet_draft_and_payment_visibility(self):
  self.apply({'invoices':[self.draft()]},self.vet);v=api.visible(api.load(self.c),self.vet)['invoices'][0];self.assertNotIn('totalCents',v);self.assertEqual(v['paymentStatus'],'unpaid')
 def test_audit_is_generated(self):
  self.apply({'reports':[{'id':'r','name':'Report'}]});self.assertEqual(api.load(self.c)['audit'][0]['actor'],'Office')
if __name__=='__main__':unittest.main()
