const vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const store=new Map(),nodes=new Map();const node=()=>({innerHTML:'',textContent:'',value:'',dataset:{},style:{},addEventListener(){},insertAdjacentHTML(){},showModal(){this.open=true},close(){this.open=false},remove(){},appendChild(){}});
const c={console,localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v)},document:{documentElement:{},createElement:node,querySelector:k=>{if(!nodes.has(k))nodes.set(k,node());return nodes.get(k)},querySelectorAll:()=>[]},navigator:{},window:{},location:{protocol:'https:'},alert(){},confirm:()=>true,crypto:require('node:crypto').webcrypto,setTimeout,Blob,URL};vm.createContext(c);
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');for(const m of html.matchAll(/<script>([\s\S]*?)<\/script>/g))vm.runInContext(m[1],c);
vm.runInContext(`
if(data.pharmacy.length!==803||data.services.length!==187||data.team.length!==17)throw Error('seed count');
if(!valid({version:1,records:data}))throw Error('backup validation');
const old=Object.fromEntries(['patient','client','xray','ultrasound','schedule','team','rehabilitation','pharmacy'].map(k=>[k,[]]));if(!valid({version:1,records:old}))throw Error('old backups');
if(cents('1.005')!==101||totals([{price:'1.005',quantity:'1'}],0,0).total!==101)throw Error('decimal rounding');
if(parseCSV('a,"b,c"')[0][1]!=='b,c')throw Error('CSV');
if(totals([{price:'12.50',quantity:'2'}],10,20).total!==2700)throw Error('invoice cents');
const r=data.pharmacy.find(r=>r.name.includes('Acetylcysteine'));if(Object.keys(JSON.parse(r.sourceData)).length!==67)throw Error('original columns');
for(const l of ['en','de']){lang=l;for(const route of ['welcome','home','cloud','receivables',...Object.keys(modules)]){page=route;render();}}
data.movements=[{id:'1',productId:'m',quantity:'10',from:'',to:'nl',batch:'A'},{id:'2',productId:'m',quantity:'3',from:'nl',to:'car',batch:'A'}];if(stockAt('m','nl','A')!==7||stockAt('m','car','A')!==3)throw Error('transfer balance');
data.payments=[{invoiceId:'i',amountCents:'200'}];data.credits=[{invoiceId:'i',amountCents:'300'}];if(outstanding({id:'i',totalCents:'1000'})!==500)throw Error('outstanding');
if(esc('<img>')!=='&lt;img&gt;')throw Error('escaping');
`,c);console.log('PASS: all bilingual routes, seed counts, old/new backup formats, source preservation, invoice totals, transfers, credits and escaping');
