const extraModules={
 locations:{en:'Stock locations',de:'Lagerorte',icon:'pill',fields:[F('name','Location name','Lagerort','text',true),F('country','Country','Land'),F('kind','Warehouse / vehicle / competition','Lager / Fahrzeug / Turnier'),F('responsible','Responsible person','Verantwortlich')]},
 movements:{en:'Stock movements',de:'Lagerbewegungen',icon:'pill',fields:[]},
 visits:{en:'Visits',de:'Besuche',icon:'horse',fields:[F('name','Visit title','Besuch','text',true),F('patientId','Patient ID','Patienten-ID'),F('clientId','Client ID','Kunden-ID'),F('doctor','Veterinarian','Tierarzt'),F('date','Date','Datum','date',true),F('findings','Findings','Befund','textarea'),F('notes','Treatment notes','Behandlungsnotizen','textarea')]},
 invoices:{en:'Invoices',de:'Rechnungen',icon:'calendar',fields:[]},
 payments:{en:'Payments',de:'Zahlungen',icon:'calendar',fields:[]},
 billing:{en:'Billing settings',de:'Abrechnungseinstellungen',icon:'calendar',fields:[F('name','Issuing entity name','Aussteller','text',true),F('country','Country code NL / CH','Ländercode NL / CH'),F('currency','Currency EUR / CHF','Währung EUR / CHF'),F('address','Address','Anschrift','textarea'),F('vatNumber','Tax registration','Steuernummer'),F('bank','Bank','Bank'),F('iban','IBAN','IBAN'),F('prefix','Invoice prefix','Rechnungspräfix'),F('firstReminder','First reminder days after due date','Erste Erinnerung nach Fälligkeit','number'),F('secondReminder','Days after first reminder','Tage nach erster Erinnerung','number'),F('reminderFee','Reminder fee (manual approval)','Mahngebühr (Freigabe erforderlich)','number')]},
 rehabPlans:{en:'Rehab plans',de:'Rehapläne',icon:'rehab',fields:[F('name','Plan title','Plantitel','text',true),F('patientId','Patient ID','Patienten-ID'),F('arrival','Arrival','Ankunft','date'),F('departure','Expected departure','Geplante Abreise','date'),F('lead','Rehab lead','Rehaleitung'),F('plan','Daily plan','Tagesplan','textarea'),F('notes','Progress notes','Verlaufsnotizen','textarea')]},
 hoofcare:{en:'Farriery',de:'Hufpflege',icon:'rehab',fields:[F('name','Entry title','Eintrag','text',true),F('patientId','Patient ID','Patienten-ID'),F('date','Date','Datum','date'),F('author','Farrier','Hufschmied'),F('notes','Hoof-care notes','Hufpflege-Notizen','textarea')]},
 reports:{en:'Shared reports',de:'Freigegebene Berichte',icon:'xray',fields:[F('name','Report title','Berichtstitel','text',true),F('patientId','Patient ID','Patienten-ID'),F('date','Date','Datum','date'),F('author','Author','Verfasser'),F('audience','internal / client / farrier / all','internal / client / farrier / all'),F('notes','Report','Bericht','textarea')]},
 audit:{en:'Activity log',de:'Aktivitätsprotokoll',icon:'calendar',fields:[]}
};Object.assign(modules,extraModules);
modules.patient.fields.push(F('clientId','Owner client ID','Eigentümer-Kunden-ID'),F('managerId','Manager account ID','Manager-Konto-ID'),F('farrierId','Farrier account ID','Hufschmied-Konto-ID'),F('location','Location','Standort'),F('assignedTo','Assigned account IDs (comma separated)','Zugeordnete Konto-IDs (kommagetrennt)'));
modules.client.fields.push(F('accountId','Linked client account ID','Verknüpfte Kundenkonto-ID'));

for(const key of ['xray','ultrasound','schedule','rehabilitation'])modules[key].fields.push(F('patientId','Linked patient','Verknüpfter Patient'));
modules.xray.fields.push(F('audience','Share with: internal / client / farrier / all','Freigabe: internal / client / farrier / all'));
modules.rehabPlans.fields.push(F('audience','Share with: internal / client / manager / all','Freigabe: internal / client / manager / all'));
modules.credits={en:'Credit notes',de:'Gutschriften',icon:'calendar',fields:[]};
