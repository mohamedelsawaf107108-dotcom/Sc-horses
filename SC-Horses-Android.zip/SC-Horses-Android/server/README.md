# Shared practice API

Python 3.11+ standard library; SQLite WAL; hashed passwords with scrypt, random expiring bearer sessions, server-enforced roles, per-horse scopes and atomic revision checks. One practice per deployment. No public server or credentials are supplied.

## Local setup (server administrator)

```bash
cd server
export SC_DATABASE=/absolute/private/path/sc-horses.sqlite3
python3 server.py --create-admin
python3 server.py --seed /absolute/path/to/local-backup.json
python3 server.py --port 8080
```

Export that backup from the app first; keep it private. Import is additive by ID, preserves existing records and is intended for initial/admin maintenance. It is not a two-way merge tool. Stop staff edits during imports. Keep the SQLite database directory on a persistent private disk. Never commit backups or database files to GitHub.

Create additional accounts in the app as admin. No accounts are created just by importing the team directory. Set individual names, email addresses, initial passwords of 12+ characters and roles. Share access privately; do not reuse one password for all staff. The current version does not provide password reset/self-service or MFA. An administrator can reset credentials with the offline command below; all that user's existing sessions are revoked.

```bash
python3 server.py --reset-password staff@example.com
```

API binds to loopback by default. Deploy as an unprivileged service on a persistent VPS, and put an HTTPS reverse proxy in front. Use a real certificate, your chosen DNS name, firewall the API port, and allow browser origin `https://appassets.androidplatform.net` (the default). For web previews explicitly set `SC_ALLOWED_ORIGINS` to comma-separated exact origins. Do not use wildcard CORS.

Example Nginx server after configuring its TLS certificate separately:

```nginx
server {
    listen 443 ssl;
    server_name api.your-domain.example;
    ssl_certificate /path/to/fullchain.pem;
    ssl_certificate_key /path/to/privkey.pem;
    client_max_body_size 20m;
    location /api/ {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Proto https;
    }
}
```

Run the app service under a process manager, not a terminal that can close. Only use the public **HTTPS origin** in the app's Cloud & accounts screen. The app permits API requests to that selected origin and keeps general WebView navigation blocked. There is no offline edit queue for shared data: failed requests do not update local cloud state.

For a consistent live backup use SQLite's backup command/API; do not copy only the `.sqlite3` file while WAL writes are active. Test restores. Sessions and passwords are sensitive even though their stored values are hashed. The service includes basic per-process login throttling; configure additional request limits at the reverse proxy for public deployments.

## Record flow

1. Admin imports the initial local backup, creates staff accounts.
2. Office links client accounts to client records; links clients, vets, technician/rehab staff, manager and farrier accounts to each horse.
3. Clinical users see only assigned horses. Reports/X-ray metadata and rehab plans must be explicitly marked for the intended external audience.
4. Vets record visits and create drafts. Office reviews price/currency/tax, issues numbered invoices, records payment or CSV receipts, and prepares reminders.
5. Stock is moved through explicit immutable ledger entries. Stock movements and payments cannot be altered/deleted after posting. Mistakes need a reviewed compensating entry, not erasing history.

Each server save applies one revision atomically. Stale clients receive an error and must refresh; records are never silently merged. Server generates audit entries and ignores client-supplied audit events. Do not treat local-mode audit records as tamper-proof.

Reminder settings are workflow configuration, not statements of legal deadlines or authorized fees. The supplied code does not calculate country tax eligibility, validate VAT IDs/IBANs, transmit bank payments or send messages automatically.
