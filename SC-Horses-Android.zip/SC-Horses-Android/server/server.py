"""SC Horses optional HTTPS-proxied API. Python 3.11+, standard library only."""
import argparse,base64,datetime,getpass,hashlib,http.cookies,json,os,secrets,sqlite3,threading,time
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
DB=os.environ.get('SC_DATABASE','sc-horses.sqlite3')
MODULES=['patient','client','xray','ultrasound','schedule','team','rehabilitation','pharmacy','services','locations','movements','visits','invoices','payments','billing','rehabPlans','hoofcare','reports','audit','credits']
CLINICAL=['patient','client','xray','ultrasound','schedule','team','rehabilitation','services','locations','visits','rehabPlans','reports','hoofcare']
PERMS={
 'admin':(MODULES,MODULES),
 'office':(MODULES,[x for x in MODULES if x!='audit']),
 'vet':(CLINICAL+['pharmacy','movements','invoices'],['patient','xray','ultrasound','schedule','rehabilitation','visits','reports','hoofcare','movements','invoices']),
 'technician':(CLINICAL+['pharmacy'],['schedule','rehabilitation','rehabPlans']),
 'rehab':(['patient','rehabilitation','rehabPlans','schedule','reports'],['rehabilitation','rehabPlans']),
 'client':(['patient','schedule','reports','rehabPlans','invoices'],[]),
 'manager':(['patient','schedule','reports','rehabPlans'],[]),
 'farrier':(['patient','xray','reports','hoofcare','schedule'],['hoofcare'])}
LOCK=threading.RLock();ATTEMPTS={}
def connect():
 c=sqlite3.connect(DB);c.execute('PRAGMA journal_mode=WAL');return c
def init():
 with connect() as c:
  c.executescript('CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE,name TEXT,role TEXT,salt TEXT,password TEXT);CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT,expires REAL);CREATE TABLE IF NOT EXISTS records(module TEXT,id TEXT,payload TEXT,PRIMARY KEY(module,id));CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value INTEGER);INSERT OR IGNORE INTO meta VALUES("revision",0);')
def password_hash(password,salt):return hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=16384,r=8,p=1).hex()
def create_user(c,name,email,password,role):
 if role not in PERMS or not 12<=len(password)<=1024 or '@' not in email:raise ValueError('Valid email, role and password of at least 12 characters required')
 salt=secrets.token_hex(16);uid=secrets.token_hex(16);c.execute('INSERT INTO users VALUES(?,?,?,?,?,?)',(uid,email.lower().strip(),name,role,salt,password_hash(password,salt)));return uid
def load(c):
 state={k:[] for k in MODULES}
 for m,i,p in c.execute('SELECT module,id,payload FROM records'):
  if m in state:state[m].append(json.loads(p))
 return state
def visible(state,u):
 uid,name,role=u;read,_=PERMS[role];out={k:[] for k in MODULES}
 patients=state['patient'];client_ids={r['id'] for r in state['client'] if r.get('accountId')==uid}
 def assigned(p):
  if role in ['admin','office']:return True
  if role=='client':return p.get('clientId') in client_ids
  if role=='manager':return p.get('managerId')==uid
  if role=='farrier':return p.get('farrierId')==uid
  return uid in [v.strip() for v in p.get('assignedTo','').split(',')]
 pids={p['id'] for p in patients if assigned(p)}
 for m in read:
  for original in state[m]:
   r=dict(original)
   if role not in ['admin','office']:
    if m=='patient' and r['id'] not in pids:continue
    if m=='client' and r['id'] not in {p.get('clientId') for p in patients if p['id'] in pids}:continue
    if m in ['xray','ultrasound','schedule','rehabilitation','visits','rehabPlans','hoofcare','reports','invoices'] and r.get('patientId') not in pids:continue
    if role in ['client','manager','farrier']:
     if m in ['reports','xray'] and r.get('audience') not in ['all',role]:continue
     if m=='patient':r={k:v for k,v in r.items() if k in ['id','name','breed','dob','microchip','location']}
     if m=='rehabPlans' and r.get('audience') not in ['all',role]:continue
     if m=='schedule':r={k:v for k,v in r.items() if k in ['id','name','patientId','date','time','location']}
     if m=='rehabPlans':r={k:v for k,v in r.items() if k in ['id','name','patientId','arrival','departure','plan']}
    if m=='pharmacy':
     for key in ['purchase','sourceData','source']:r.pop(key,None)
    if m=='invoices':
     paid=sum(int(p.get('amountCents','0')) for p in state['payments']+state['credits'] if p.get('invoiceId')==r['id'])
     r['outstandingCents']=str(max(0,int(r.get('totalCents','0'))-paid));r['paymentStatus']='paid' if paid>=int(r.get('totalCents','0')) and r.get('status')=='issued' else 'unpaid'
    if m=='invoices' and role=='vet':r={k:v for k,v in r.items() if k in ['id','name','patientId','clientId','status','number','date','due','createdBy','paymentStatus']}
   out[m].append(r)
 return out
def state_result(c,u):
 return {'records':visible(load(c),u),'revision':c.execute('SELECT value FROM meta WHERE key="revision"').fetchone()[0]}
def numeric(v):
 try:
  n=float(v)
  if not __import__('math').isfinite(n):raise ValueError()
  return n
 except:raise ValueError('Invalid numeric value')
def commit_state(c,u,request):
 current_revision=c.execute('SELECT value FROM meta WHERE key="revision"').fetchone()[0]
 if request.get('revision')!=current_revision:raise ValueError('Another user updated the workspace. Refresh before saving.')
 incoming=request.get('records');full=load(c);view=visible(full,u);_,write=PERMS[u[2]];changes=[]
 if not isinstance(incoming,dict):raise ValueError('Invalid records')
 for m,rows in incoming.items():
  if m not in MODULES or not isinstance(rows,list):raise ValueError('Invalid module')
  if len(rows)>10000:raise ValueError('Too many records')
  ids=set()
  for r in rows:
   if not isinstance(r,dict) or not isinstance(r.get('id'),str) or r['id'] in ids or any(not isinstance(v,str) for v in r.values()):raise ValueError('Records must contain unique string IDs and string fields')
   ids.add(r['id'])
  old={r['id']:r for r in view[m]};new={r['id']:r for r in rows};hidden={r['id'] for r in full[m]}-set(old)
  for rid in set(old)|set(new):
   if old.get(rid)==new.get(rid):continue
   if m=='audit':continue
   if m not in write or rid in hidden:raise ValueError('Permission denied for '+m)
   before=next((r for r in full[m] if r['id']==rid),None);after=new.get(rid)
   if m in ['movements','payments','credits'] and before:raise ValueError('Ledger entries cannot be edited or deleted')
   if m=='invoices' and before and before.get('status')=='issued':raise ValueError('Issued invoices are locked; use a separately reviewed correction process')
   if u[2]=='vet' and m=='invoices':
    if before or not after or after.get('status')!='draft':raise ValueError('Veterinarians may create drafts only; office reviews and issues them')
   if after:
    after={**(before or {}),**after}
    after.pop('outstandingCents',None);after.pop('paymentStatus',None)
    if u[2] not in ['admin','office'] and m in ['patient','xray','ultrasound','schedule','rehabilitation','visits','rehabPlans','hoofcare','reports','invoices']:
     allowed={p['id'] for p in view['patient']}
     if (m=='patient' and (not before or rid not in allowed)) or (m!='patient' and after.get('patientId') not in allowed):raise ValueError('Patient outside assigned scope')
     if m=='patient' and any(after.get(k)!=before.get(k) for k in ['clientId','assignedTo','farrierId','managerId']):raise ValueError('Only office may change patient access')
    if m=='movements':
     q=numeric(after.get('quantity','0'));kind=after.get('kind');src=after.get('from','');dst=after.get('to','')
     if q<=0 or kind not in ['receipt','transfer','use','waste']:raise ValueError('Invalid stock movement')
     locs={r['id'] for r in full['locations']}
     if (kind=='receipt' and (src or dst not in locs)) or (kind=='transfer' and (src not in locs or dst not in locs or src==dst)) or (kind in ['use','waste'] and (src not in locs or dst)):raise ValueError('Invalid stock locations')
     if kind=='use' and after.get('patientId') not in {p['id'] for p in view['patient']}:raise ValueError('Invalid patient')
     if after.get('productId') not in {p['id'] for p in full['pharmacy']}:raise ValueError('Invalid medicine')
     balance=sum((numeric(v['quantity']) if v.get('to')==src else 0)-(numeric(v['quantity']) if v.get('from')==src else 0) for v in full['movements'] if v.get('productId')==after.get('productId') and v.get('batch','')==after.get('batch',''))
     if src and balance<q:raise ValueError('Insufficient batch stock')
    if m in ['payments','credits']:
     inv=next((i for i in full['invoices'] if i['id']==after.get('invoiceId') and i.get('status')=='issued'),None)
     if not inv:raise ValueError('Issued invoice required')
     amount=numeric(after.get('amountCents','0'));paid=sum(numeric(p['amountCents']) for p in full['payments']+full['credits'] if p.get('invoiceId')==inv['id'])
     if amount<=0 or amount%1 or after.get('currency')!=inv.get('currency') or paid+amount>numeric(inv.get('totalCents','0')):raise ValueError('Invalid payment amount or currency')
    if m=='payments' and after.get('reference') and any(p.get('invoiceId')==after.get('invoiceId') and p.get('reference')==after.get('reference') and p.get('date')==after.get('date') and p.get('amountCents')==after.get('amountCents') for p in full['payments']):raise ValueError('Duplicate bank payment')
    if m=='credits':
     if not after.get('reason'):raise ValueError('Credit reason required')
     after['name']=inv['number']+'-CN-'+str(1+sum(1 for r in full['credits'] if r.get('invoiceId')==inv['id']))
    if m=='invoices':
     from decimal import Decimal,ROUND_HALF_UP
     rnd=lambda n:int(Decimal(str(n)).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
     try:items=json.loads(after['items']);discount=numeric(after.get('discount','0'));tax=numeric(after.get('tax','0'))
     except:raise ValueError('Invalid invoice items')
     if after.get('status') not in ['draft','issued'] or after.get('taxMode') not in ['standard','reverse','exempt']:raise ValueError('Invalid invoice status or tax treatment')
     if after.get('taxMode')!='standard' and (tax!=0 or not after.get('taxReason')):raise ValueError('Tax exemption needs zero tax and a reason')
     if not items or not 0<=discount<=100 or not 0<=tax<=100:raise ValueError('Invalid invoice percentages')
     sub=0
     for item in items:
      q=numeric(item['quantity']);price=numeric(item['price'])
      if q<=0 or price<0:raise ValueError('Invalid invoice line')
      sub+=rnd(rnd(Decimal(str(price))*100)*Decimal(str(q)))
     net=sub-rnd(Decimal(sub)*Decimal(str(discount))/100);total=net+rnd(Decimal(net)*Decimal(str(tax))/100)
     if str(total)!=after.get('totalCents'):raise ValueError('Invoice total mismatch')
     if after.get('status')=='issued':
      if u[2] not in ['admin','office']:raise ValueError('Only office can issue invoices')
      if after.get('currency') not in ['EUR','CHF'] or not after.get('entitySnapshot') or not after.get('clientSnapshot') or not after.get('number'):raise ValueError('Invoice snapshots and number required')
      entity=next((e for e in full['billing'] if e['id']==after.get('entityId')),None);client=next((e for e in full['client'] if e['id']==after.get('clientId')),None)
      if not entity or not client or not all(entity.get(k) for k in ['prefix','address','vatNumber']) or entity.get('currency')!=after['currency']:raise ValueError('Complete billing entity and client required')
      datetime.date.fromisoformat(after['date']);datetime.date.fromisoformat(after['due'])
      prefix=entity['prefix']+'-';used=[int(i.get('number','')[len(prefix):]) for i in full['invoices'] if i.get('number','').startswith(prefix) and i.get('number','')[len(prefix):].isdigit()]
      after['number']=prefix+str(max(used,default=0)+1).zfill(6);after['name']=after['number']
      after['entitySnapshot']=json.dumps(entity,ensure_ascii=False);after['clientSnapshot']=json.dumps(client,ensure_ascii=False)
    after['updatedBy']=u[0];after['updatedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
   changes.append((m,rid,after))
   full[m]=[r for r in full[m] if r['id']!=rid]+([after] if after else [])
 for m,rid,after in changes:
  if after:c.execute('INSERT OR REPLACE INTO records VALUES(?,?,?)',(m,rid,json.dumps(after,ensure_ascii=False)))
  else:c.execute('DELETE FROM records WHERE module=? AND id=?',(m,rid))
  audit={'id':secrets.token_hex(16),'name':'Saved' if after else 'Deleted','module':m,'recordId':rid,'actor':u[1],'date':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  c.execute('INSERT INTO records VALUES(?,?,?)',('audit',audit['id'],json.dumps(audit)))
 c.execute('UPDATE meta SET value=value+1 WHERE key="revision"')
 return state_result(c,u)
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def origin(self):
  allowed=os.environ.get('SC_ALLOWED_ORIGINS','https://appassets.androidplatform.net').split(',');o=self.headers.get('Origin','');return o if o in allowed else ''
 def respond(self,status,payload):
  raw=json.dumps(payload,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Content-Length',str(len(raw)))
  if self.origin():self.send_header('Access-Control-Allow-Origin',self.origin());self.send_header('Vary','Origin')
  self.end_headers();self.wfile.write(raw)
 def do_OPTIONS(self):
  self.send_response(204)
  if self.origin():self.send_header('Access-Control-Allow-Origin',self.origin())
  self.send_header('Access-Control-Allow-Headers','Authorization, Content-Type');self.send_header('Access-Control-Allow-Methods','GET, POST, PUT, OPTIONS');self.end_headers()
 def user(self,c):
  token=self.headers.get('Authorization','').removeprefix('Bearer ');row=c.execute('SELECT u.id,u.name,u.role FROM users u JOIN sessions s ON u.id=s.user_id WHERE s.token=? AND s.expires>?',(hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone();return row
 def handle_api(self,method):
  try:
   size=int(self.headers.get('Content-Length','0'))
   if size>20_000_000:return self.respond(413,{'error':'Request too large'})
   body=json.loads(self.rfile.read(size)) if size else {}
   if not isinstance(body,dict):raise ValueError('JSON object required')
   if len(str(body.get('password','')))>1024:raise ValueError('Password too long')
   with LOCK,connect() as c:
    if method=='POST' and self.path=='/api/login':
     ip=self.client_address[0];recent=[t for t in ATTEMPTS.get(ip,[]) if t>time.time()-60];ATTEMPTS[ip]=recent
     if len(recent)>=10:return self.respond(429,{'error':'Too many attempts; try again later'})
     recent.append(time.time());u=c.execute('SELECT id,name,role,salt,password FROM users WHERE email=?',(str(body.get('email','')).strip().lower(),)).fetchone()
     if not u or not secrets.compare_digest(password_hash(str(body.get('password','')),u[3]),u[4]):return self.respond(401,{'error':'Invalid email or password'})
     token=secrets.token_urlsafe(40);c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),u[0],time.time()+8*3600));c.commit();return self.respond(200,{'token':token,'user':{'id':u[0],'name':u[1],'role':u[2]},'permissions':{'read':PERMS[u[2]][0],'write':PERMS[u[2]][1]}})
    u=self.user(c)
    if not u:return self.respond(401,{'error':'Sign in required'})
    if self.path=='/api/state' and method=='GET':return self.respond(200,state_result(c,u))
    if self.path=='/api/state' and method=='PUT':
     result=commit_state(c,u,body);c.commit();return self.respond(200,result)
    if self.path=='/api/logout' and method=='POST':
     token=self.headers.get('Authorization','').removeprefix('Bearer ');c.execute('DELETE FROM sessions WHERE token=?',(hashlib.sha256(token.encode()).hexdigest(),));c.commit();return self.respond(200,{'ok':True})
    if self.path=='/api/users' and method=='GET' and u[2] in ['admin','office']:
     return self.respond(200,{'users':[dict(zip(['id','name','email','role'],r)) for r in c.execute('SELECT id,name,email,role FROM users ORDER BY name')]})
    if self.path=='/api/users' and method=='POST' and u[2]=='admin':
     uid=create_user(c,body['name'],body['email'],body['password'],body['role']);c.commit();return self.respond(201,{'id':uid})
    return self.respond(403,{'error':'Permission denied'})
  except (ValueError,KeyError,TypeError,sqlite3.IntegrityError) as e:return self.respond(400,{'error':str(e)})
  except Exception:return self.respond(500,{'error':'Server error; changes were not committed'})
 def do_GET(self):self.handle_api('GET')
 def do_POST(self):self.handle_api('POST')
 def do_PUT(self):self.handle_api('PUT')
def main():
 p=argparse.ArgumentParser();p.add_argument('--create-admin',action='store_true');p.add_argument('--reset-password');p.add_argument('--seed',type=Path);p.add_argument('--port',type=int,default=8080);a=p.parse_args();init()
 if a.create_admin:
  name=input('Admin name: ');email=input('Admin email: ');password=getpass.getpass('Password (12+ characters): ')
  with connect() as c:create_user(c,name,email,password,'admin')
  print('Admin created');return
 if a.reset_password:
  password=getpass.getpass('New password (12+ characters): ')
  if not 12<=len(password)<=1024:raise ValueError('Password must have 12–1024 characters')
  with connect() as c:
   row=c.execute('SELECT id FROM users WHERE email=?',(a.reset_password.lower().strip(),)).fetchone()
   if not row:raise ValueError('Account not found')
   salt=secrets.token_hex(16);c.execute('UPDATE users SET salt=?,password=? WHERE id=?',(salt,password_hash(password,salt),row[0]));c.execute('DELETE FROM sessions WHERE user_id=?',(row[0],))
  print('Password changed; existing sessions revoked');return
 if a.seed:
  raw=json.loads(a.seed.read_text());records=raw.get('records',raw)
  with connect() as c:
   for module,rows in records.items():
    if module not in MODULES:continue
    for r in rows:c.execute('INSERT OR IGNORE INTO records VALUES(?,?,?)',(module,r['id'],json.dumps(r,ensure_ascii=False)))
   c.execute('UPDATE meta SET value=value+1 WHERE key="revision"')
  print('Seed loaded without overwriting existing IDs');return
 print('Listening on loopback; publish only behind HTTPS reverse proxy.')
 ThreadingHTTPServer((os.environ.get('SC_BIND','127.0.0.1'),a.port),Handler).serve_forever()
if __name__=='__main__':main()
